
/* 


 * Student Info: Name=Chapadia Shruti, ID=15574CS

 * Subject:CS526(B)_HWNo -2_Summer_2016

 * Author: shruti

 * Filename: oscdb.sql

 * Date and Time: Jul 1, 2016 3:08:06 PM

 * Project Name: PhpProjectOSCSite


 */

/**
 * Author:  shruti
 * Created: Jul 1, 2016
 */

drop database if exists osc_db;
create database osc_db; use osc_db;


Drop table student;


CREATE table student(
student_id  int(15) NOT NULL,
FirstName   varchar(25),
LastName    varchar(25),
Status  varchar(10));

insert into student values( 1000, 'sam', 'lam', 1);
insert into student values(1001, 'zill', 'dan', 1);

grant select, insert, delete,update on osc_db. *to admin@localhost identified by 'password';

