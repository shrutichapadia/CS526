
/* 


 * Student Info: Name=Chapadia Shruti, ID=15574CS

 * Subject:CS526(B)_HWNo -2_Summer_2016

 * Author: shruti

 * Filename: osc_db.sql

 * Date and Time: Jun 21, 2016 7:52:44 PM

 * Project Name: PhpProjectOSCSite


 */

/**
 * Author:  shruti
 * Created: Jun 21, 2016
 */

DROP DATABASE IF EXISTS osc_database;

CREATE DATABASE osc_database;

USE osc_database;
 

CREATE TABLE publishers (
  publisherID       INT(11)        NOT NULL   AUTO_INCREMENT,
  publisherName     VARCHAR(255)   NOT NULL,
  PRIMARY KEY (publisherID)
);


CREATE TABLE books (
  bookID           INT(11)        NOT NULL   AUTO_INCREMENT,
  publisherID      INT(11)        NOT NULL,
  isbn             VARCHAR(20)    NOT NULL   UNIQUE,
  bookTile         VARCHAR(255)   NOT NULL,
  bookPrice        DECIMAL(10,2)  NOT NULL,
  PRIMARY KEY (bookID)
);


INSERT INTO publishers VALUES
(1, 'Apress'),
(2, 'Microsoft Press'),
(3, 'Sams Publishing');


INSERT INTO books VALUES
(1, 1, '1010101010', 'Programming in Java', '69.00'),
(2, 2, '1010101011', 'Programming in C#', '59.00'),
(3, 3, '1010101102', 'Web Progamming with PHP', '25.17'),
(5, 1, '1010101103', 'Cisco Networking', '89.99'),



GRANT SELECT, INSERT, DELETE, UPDATE
ON osc_database.*
TO admin@localhost
IDENTIFIED BY 'pass@word';


GRANT SELECT
ON books
TO peter@localhost
IDENTIFIED BY 'pass@word';