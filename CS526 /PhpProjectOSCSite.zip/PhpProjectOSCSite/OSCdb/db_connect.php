<?php

/* 


 * Student Info: Name=Chapadia Shruti, ID=15574CS

 * Subject:CS526(B)_HWNo -2_Summer_2016

 * Author: shruti

 * Filename: db_connect.php

 * Date and Time: Jun 29, 2016 10:27:29 AM

 * Project Name: PhpProjectOSCSite


 */

$dsn = 'mysql:host=localhost;dbname=osc_db';
$username = 'admin';
$password = 'password';

try {
    $db = new PDO($dsn,$username,$password);
    echo 'connected';
} catch (PDOException $ex){
    $error_msg = $ex->getMessage();
   
}

























       // $con = mysql_connect($server, $username, $password);
//        $con = mysql_database("localhost","user" ,"password");
//        if (!$con){
//            exit('connect error (' .  mysqli_connect_errno().')'
//                    .mysqli_connect_error());
//        } else {echo "connection is ok";}
//   $query =  mysql_query("select * from student_repo where 'FirstName' = '$FirstName'", $con);
//   $row = mysql_fetch_array($query);
//   
//   function get_StudentRepo(){
//       global $db;
//       $query = 'select * from StudentRepo';
//       $FirstName = $db->query($query);
//       return $FirstName;
//   }
   


 
//class DB {
// 
//    public $db_name = 'osc_database';
//    public $db_user = 'root';
//    public $db_pass = '';
//    public $db_host = 'localhost';
// 
//    //open a connection to the database. Make sure this is called
//    //on every page that needs to use the database.
//    public function connect() {
//        $connection = mysql_connect($thisdb_host, $thisdb_user, $thisdb_pass);
//        mysql_select_db($thisdb_name);
// 
//        return true;
//    }
// 
//    //takes a mysql row set and returns an associative array, where the keys
//    //in the array are the column names in the row set. If singleRow is set to
//    //true, then it will return a single row instead of an array of rows.
//    public function processRowSet($rowSet, $singleRow=false)
//    {
//        $resultArray = array();
//        while($row = mysql_fetch_assoc($rowSet))
//        {
//            array_push($resultArray, $row);
//        }
// 
//        if($singleRow === true)
//            return $resultArray[0];
// 
//        return $resultArray;
//    }
// 
//    //Select rows from the database.
//    //returns a full row or rows from $table using $where as the where clause.
//    //return value is an associative array with column names as keys.
//    public function select($table, $where) {
//        $sql = "SELECT * FROM $table WHERE $where";
//        $result = mysql_query($sql);
//        if(mysql_num_rows($result) == 1)
//            return $thisprocessRowSet($result, true);
// 
//        return $thisprocessRowSet($result);
//    }
// 
//    //Updates a current row in the database.
//    //takes an array of data, where the keys in the array are the column names
//    //and the values are the data that will be inserted into those columns.
//    //$table is the name of the table and $where is the sql where clause.
//    public function update($data, $table, $where) {
//        foreach ($data as $column =>$value) {
//            $sql = "UPDATE $table SET $column = $value WHERE $where";
//            mysql_query($sql) or die(mysql_error());
//        }
//        return true;
//    }
// 
//    //Inserts a new row into the database.
//    //takes an array of data, where the keys in the array are the column names
//    //and the values are the data that will be inserted into those columns.
//    //$table is the name of the table.
//    public function insert($data, $table) {
// 
//        $columns = "";
//        $values = "";
// 
//        foreach ($data as $column => $value) {
//            $columns .= ($columns == "") ? "" : ", ";
//            $columns .= $column;
//            $values .= ($values == "") ? "" : ", ";
//            $values .= $value;
//        }
// 
//        $sql = "insert into $table ($columns) values ($values)";
// 
//        mysql_query($sql) or die(mysql_error());
// 
//        //return the ID of the user in the database.
//        return mysql_insert_id();
// 
//    }
// 
//}
//// $db = new DB();
//// 
//////connect to the database
////db_connect();
//
//
?>