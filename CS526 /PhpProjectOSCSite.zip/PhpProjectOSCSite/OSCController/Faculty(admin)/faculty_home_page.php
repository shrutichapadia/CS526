<!DOCTYPE html>

<!--


Student Info: Name=Chapadia Shruti, ID=15574CS

Subject:CS526(B)_HWNo -2_Summer_2016

Author: shruti

Filename: faculty_home_page.php

Date and Time: Jun 20, 2016 8:58:16 PM

Project Name: PhpProjectOSCSite


-->






<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    <h1 style="color: purple"> Faculty Home Page </h1>
    </head>
    <body>
                    

        <label> week No  </label>
             <input type="week" />
             <br><br>
             <A HREF="attendance_page.php">Click Attendance_page</A>
             <BR><br><br>
             <A HREF="assignment_page.php">Click Assignment_page</A>
             <br><br><br>
             <A HREF="handout_page.php">Click Handout_page</A>
             <form method="post" action="attendance_page.php">
            <A HREF="OSCView/attendance_page.php"></A>
           
            
        <?php
        // put your code here
        
        
//     
//include 'OSCdb/db_connect.php';
//include 'OSCView/attendance_page.php';
//include 'OSCView/assignment_page.php';
//include 'OSCView/handout_page.php';
// 
class User {
 
    public $id;
    public $username;
    public $Password;
    public $email;

 
    //Constructor is called whenever a new object is created.
    //Takes an associative array with the DB row as an argument.
    function __construct($data) {
        $this->id = (isset($data['id'])) ? $data['id'] : "";
        $this->username = (isset($data['username'])) ? $data['username'] : "";
        $this->Password = (isset($data['password'])) ? $data['password'] : "";
        $this->email = (isset($data['email'])) ? $data['email'] : "";
        
    }
 
    public function save($isNewUser = false) {
        //create a new database object.
        $db = new DB();
        
        //if the user is already registered and we're
        //just updating their info.
        if(!$isNewUser) {
            //set the data array
            $data = array(
                "username" => "'$this->username'",
                "password" => "'$this->Password'",
                "email" => "'$this->email'"
            );
            
            //update the row in the database
            $db->update($data, 'users', 'id = '.$this->id);
        }else {
        //if the user is being registered for the first time.
            $data = array(
                "username" => "'$this->username'",
                "password" => "'$this->Password'",
                "email" => "'$this->email'",
                "join_date" => "'".date("Y-m-d H:i:s",time())."'"
            );
            
            $this->id = $db->insert($data, 'users');
            $this->joinDate = time();
        }
        return true;
    }
    
}


        ?>
            </form>
        <form method="post" action="assignment_page.php"></form>
        <form method="post" action="handout_page.php"></form>
    </body>
</html>
