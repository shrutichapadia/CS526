<!DOCTYPE html>

<!--


Student Info: Name=Chapadia Shruti, ID=15574CS

Subject:CS526(B)_HWNo -2_Summer_2016

Author: shruti

Filename: save_attendance.php

Date and Time: Jun 20, 2016 8:55:27 PM

Project Name: PhpProjectOSCSite


-->

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // put your code here
        ?>
    </body>
</html>
