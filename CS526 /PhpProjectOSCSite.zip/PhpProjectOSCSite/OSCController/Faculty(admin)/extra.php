<!DOCTYPE html>

<!--


Student Info: Name=Chapadia Shruti, ID=15574CS

Subject:CS526(B)_HWNo -2_Summer_2016

Author: shruti

Filename: extra.php

Date and Time: Jul 3, 2016 8:35:00 PM

Project Name: PhpProjectOSCSite


-->

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // put your code here
        ?>
    </body>
</html>
            Week No::2: <input type="radio" name="Week No" value="<?php echo $week_no ?>"/>
            Week No::3: <input type="radio" name="Week No" value="<?php echo $week_no ?>"/>
            Week No::4: <input type="radio" name="Week No" value="<?php echo $week_no ?>"/>
            Week No::5: <input type="radio" name="Week No" value="<?php echo $week_no ?>"/>
            Week No::6: <input type="radio" name="Week No" value="<?php echo $week_no ?>"/>
            Week No::7: <input type="radio" name="Week No" value="<?php echo $week_no ?>"/>
            Week No::8: <input type="radio" name="Week No" value="<?php echo $week_no ?>"/>
            <br>
            Week No::9: <input type="radio" name="Week No" value="<?php echo $week_no ?>"/>
            Week No::10: <input type="radio" name="Week No" value="<?php echo $week_no ?>"/>
            Week No::11: <input type="radio" name="Week No" value="<?php echo $week_no ?>"/>
            Week No::12: <input type="radio" name="Week No" value="<?php echo $week_no ?>"/>
            Week No::13: <input type="radio" name="Week No" value="<?php echo $week_no ?>"/>
            Week No::14: <input type="radio" name="Week No" value="<?php echo $week_no ?>"/>
            Week No::15: <input type="radio" name="Week No" value="<?php echo $week_no ?>"/>

            
             <textarea rows="10" cols="50"></textarea> 