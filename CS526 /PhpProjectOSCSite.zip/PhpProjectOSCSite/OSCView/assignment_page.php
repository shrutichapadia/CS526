
<!DOCTYPE html>

<!--


Student Info: Name=Chapadia Shruti, ID=15574CS

Subject:CS526(B)_HWNo -2_Summer_2016

Author: shruti

Filename: assignment_page.php

Date and Time: Jun 20, 2016 9:02:50 PM

Project Name: PhpProjectOSCSite


-->

<html>
    <head>
        <meta charset="UTF-8">
        <title>Assignment Link</title>
    </head>
    <body>

 <style>
table, th, td {
    border: 1px solid black;
}
</style>
        <h1 style="color: purple">Assignment update page</h1>
        <form action ="show_assignment_page.php" method="post" id="assignment">
            <label> week No  </label>
            <input type="week" />
            <br>
            <br>
            
            <table>
            <tbody>
            <tr>
            <td>Assignment Question</td> 
            <br>
            <td width="100%" rowspan="50"colspan="100"/>
          
            </tr>
            </tbody>
            </table>
            
            
             Due Date: <input type="date" value ="<?php $duedate;?>"/>  
            
             
              <label>Total Marks: </label>
            <input type ="text"  name="total marks">
            <br>
            <br><br><br>
            <input type="submit" value="Assignment Detail" /> 
            
            <label>Total Marks: </label>
            <input type ="text"  name="total marks">
  
            <br><br> <br>
            <input type ="button" style="color: blue"  value="submit">
          
        </form>
</body>

</html>     