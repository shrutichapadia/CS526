<!DOCTYPE html>

<!--


Student Info: Name=Chapadia Shruti, ID=15574CS

Subject:CS526(B)_HWNo -2_Summer_2016

Author: shruti

Filename: attendance_page.php

Date and Time: Jun 20, 2016 8:59:28 PM

Project Name: PhpProjectOSCSite


-->

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <style>
        table, th, td {
    border: 1px solid black;
        }
        </style>

        <h1 style="color: purple">Attendance Page</h1>
        <label> week No  </label>
             <input type="week" />
             
             <br><br><br>
        <form method="post" action="index.php" enctype="multipart/form data>
            

        <label> week No  </label>
             <input type="week" />
    <table>
    <tr>
        <th> Number </th>
        <th> Student_id <?php echo $student_id?> </th>
        <th> Student FirstName <?php echo $FirstName ?> </th>
        <th> Student LastName <?php echo $LastName ?> </th>
        <th> Status <?php echo $status ?></th>
        <td row="20">
           
                <ul>
                    <li> <input type="button"  type="button"/> Present</li>
                    <li> <input type="button" name="Present" type="button"/> Absent </li>
                     <li> <input type="button" name="Present" type="button"/> Leaving Early</li>
                    <li>  <input type="button" name="Present" type="button"/> Late </li>   

                </ul>
                
            </div
        </td>

    </tr>
</table>
             <br><br><br><br>
            <input type="submit" action="submit" name="Submit" style="color: blue" style="font-style: inherit"/>
         
        </form> 

 <?php
        
        ?>
    </body>
</html>