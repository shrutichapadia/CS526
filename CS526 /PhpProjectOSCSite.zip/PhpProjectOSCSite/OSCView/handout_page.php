<!DOCTYPE html>

<!--


Student Info: Name=Chapadia Shruti, ID=15574CS

Subject:CS526(B)_HWNo -2_Summer_2016

Author: shruti

Filename: handout_page.php

Date and Time: Jun 20, 2016 9:01:47 PM

Project Name: PhpProjectOSCSite


-->

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <style>
table, th, td {
    border: 1px solid black;
}
</style>
        <h1 style="color: purple">Handout Upload Page</h1>
        <form method="post" action="show_assignment_page.php" enctype="multipart/form data>
            <h2> Handout page</h2>
            Week No::1: <input type="radio" name="Week No" value="<?php echo $week_no ?>"/>

            <h4>Handout upload</h4>
            <table style="width: 100%" cellborder="5" >
                <tbody>
                    <tr>                    
                        <th>Week No</th>
                        <th>Handout</th>
                        </td>
                    </tr>
                    <tr>
                       
                        <td style="width: 20%" style="height:50%"> 
                            <b> Week 1 </b>  
                            <td style="height:50%"/> 
                <b  style="height:50%">
                    Detail:
                </b>
                            </td>
                    </tr>
                    
                </tbody>
            </table>
            
             <br><br><br>
             
            <input type="submit" action="submit" name="Submit" style="color: blue" style="font-style: inherit"/>
         
        </form> 

 <?php
        
        ?>
    </body>
</html>
