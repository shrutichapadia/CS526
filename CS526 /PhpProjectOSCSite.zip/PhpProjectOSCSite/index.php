<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->


<?php
//include "Student.php";
$faculty='';
$FirstName='';
$action='';
$subject_id='';

$FirstName =$_POST[$FirstName];
$action = $_POST[$action];
//include "OSCModel/db_connect.php";
?>
<!DOCTYPE html>
<?php
//require 'db_connect.php';

$student_id = 1;
if (isset($_GET['faculty_id'])) {
    $faculty_id = $_GET['faculty_id'];
}

if(isset($_POST['action'])){
    $action = $_post['action'];
}

if($action == submit){
    $login = $_POST['login'];
    $password = $_POST['password'];
    $action = $_POST['action'];
    include 'faculty_home_page.php';  
}

// Get the current publisher's name
//$subject_id = "SELECT subjectlist FROM subject WHERE subjectID = '$subject_id'";
//$faculty = $db->query($subject_id);
//$faculty = $faculty->fetch();
//$faculty_name = $faculty['facultyname'];
//
////// Get the publisher list
//$query = "SELECT * FROM faculty ORDER BY subject_id";
//$faculty = $db->query($query);
//
//// Get books for the selected publisher
//$query = "SELECT * FROM week WHERE weekno = $week_no ORDER BY weekno";
//$week_no = $db->query($query);

?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>OSC College</title>
        <link rel="stylesheet" type="text/css" href="style.css" />
    </head>
    <body>
        <h1 align=" center" style="color:mediumvioletred">Wellcome to OSC College </h1>
        <h1 style="color: purple">Manage Faculty Page</h1>
        
        <form method="post" action="index.php">
            Login:   <input type="text" value="<?php echo $faculty_id ?>"/>
            <br>
            Password:<input type="text" value="<?php echo $password ?>"/>
            <br><BR>
            <input type="submit" color="blue" name="submit" action="submit" style="color: blue" font="bold">
        </form>
              
    </body>
</html>